package ME;
import java.util.Scanner;
public class Conta {
    Scanner sc = new Scanner(System.in);
    private int numero;
    String nome;
    double saldo = 0;

    public void setNome() {
        System.out.println("Digite o Nome do propriétário: ");
        this.nome = nome;
    }

    public void setNumero() {
        System.out.println("Digite o numero da conta: ");
         this.numero = numero;
    }
    public void deposito_inicial(){
        System.out.println("Foi feito um depósito inicial?(S/N)");
        String si = sc.nextLine();
        si.toLowerCase();
        if (si.equals("s")){
            System.out.println("Digite o valor do depósito inicial: ");
           double di = sc.nextDouble();
            saldo =+ di;
        } else if (si.equals("n")) {;

        }else{
            System.out.println("Não entendi pode repetir?");
            deposito_inicial();
        }
        System.out.printf("Conta:"+numero," Nome:"+nome,"Saldo: $"+saldo);
    }
    public void deposito(){
        System.out.println("Digite a quantia a ser depositada: ");
        double valor = sc.nextDouble();
        saldo =+ valor;
        System.out.println("Conta Atualizada:");
        System.out.printf("Conta:"+numero," Nome:"+nome,"Saldo: $"+saldo);
    }
    public void saque(){
        System.out.println("Digite a quantia a ser depositada: ");
        double valor = sc.nextDouble();
        saldo =- valor;
        System.out.println("Conta Atualizada:");
        System.out.printf("Conta:"+numero," Nome:"+nome,"Saldo: $"+saldo);
    }

}
