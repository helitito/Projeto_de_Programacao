package ME;
import ME.Conta;
public class Program {
    public static void main(String[] args) {
        Conta novaconta = new Conta();
        novaconta.setNome();
        novaconta.setNumero();
        novaconta.deposito_inicial();
        novaconta.deposito();
        novaconta.saque();
        }
    }
