package Q2;

public class Main {
    public static void main(String[] args) {
Pessoa aluno1 = new Pessoa();
aluno1.setNome("leo");
aluno1.setCPF(1234567891);
aluno1.setIdade(20);
aluno1.ValidaCPF(aluno1.getCPF());
    }
}