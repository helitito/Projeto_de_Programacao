package Q2;

import java.util.Scanner;
public class Pessoa {
    Scanner sc = new Scanner(System.in);
    public String nome;
    private int CPF;

    public int idade;

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }
    public int getCPF() {
        return CPF;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void ValidaCPF(int CPF){
        System.out.println("CPF validado!");
    }
}
