package Q3;
import java.util.Objects;
import java.util.Scanner;
public class Lampada {
    Scanner sc = new Scanner(System.in);
    public String dim;
    public int brilho;

    public String ld = "d";

    public void setDim() {
        System.out.println("A lampada é dimerizavel?(S/N)");
        dim = sc.nextLine();
    }

    //LIGAR LAMPADA
    public void liga() {
        System.out.println("O que deseja fazer?(L/D)Digite 'sair' para sair");
        ld = sc.nextLine();
        String lowerld = ld.toLowerCase();
        String lowerdim = dim.toLowerCase();
        if (lowerld.equals("l") && (dim.equals("n"))) {
            System.out.println("Lampada ligada!");
            liga();
        } else if ("l".equals(lowerld) && dim.equals("s")) {
            System.out.println("Qual o brilho desejado?0-100");
            brilho = sc.nextInt();
            System.out.println("Lampada ligada!");
            System.out.println("O brilho está em: "+brilho);
            liga();
        } else if (ld.equals("d")) {
            System.out.println("Lampada Desligada!");
            liga();
        } else if(ld.equals("sair")){;}
        else {
            System.out.println("Não entendi Digite novamente.");
            liga();
        }
    }
}



