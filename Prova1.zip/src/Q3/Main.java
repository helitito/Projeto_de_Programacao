package Q3;

public class Main {
    public static void main(String[] args) {
        Lampada a = new Lampada();
        a.setDim();
        a.liga();
    }
}
