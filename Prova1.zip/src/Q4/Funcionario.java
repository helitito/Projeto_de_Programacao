package Q4;
import java.util.Scanner;
public class Funcionario {
    Scanner sc = new Scanner(System.in);
    String nome;
    double salariobruto;
    double imposto;

    double networth;

    public void cria() {
        System.out.println("Digite o Nome: ");
        this.nome = sc.nextLine();
        System.out.println("Digite o Salario: ");
        this.salariobruto = sc.nextDouble();
        System.out.println("Digite o Imposto: ");
        this.imposto = sc.nextDouble();
        double networth = salariobruto - imposto;
        System.out.println("Funcionario:"+nome+networth);
    }


    public void aumento() {
        double percent;
        System.out.println("Digite a porcentagem do aumento: ");
        percent = sc.nextDouble();
        salariobruto = salariobruto * (percent/100);
        System.out.println(salariobruto);
    }
}