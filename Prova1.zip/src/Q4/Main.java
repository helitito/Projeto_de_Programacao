package Q4;

public class Main {
    public static void main(String[] args) {
        Funcionario a = new Funcionario();
      a.cria();
      a.aumento();
}
}
