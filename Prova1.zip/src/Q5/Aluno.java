package Q5;

import java.util.Scanner;

public class Aluno {
    Scanner sc = new Scanner(System.in);
    public String nome;
    int matricula;
    String curso;

    String disciplina1;
    String disciplina2;

    public void cria(){
        System.out.println("Digite o nome do Aluno: ");
        nome = sc.nextLine();

        System.out.println("Digite o Curso: ");
        curso = sc.nextLine();
        System.out.println("Digite a Matricula: ");
        matricula = sc.nextInt();
        sc.nextLine();
        System.out.println("Digite a primeira Disciplina: ");
        disciplina1= sc.nextLine();

        System.out.println("Digite a segunda Disciplina: ");
        disciplina2 = sc.nextLine();
    }

    public void aprova(){
        System.out.printf("Para a matéria "+disciplina1," :%n");
        System.out.println("Digite a primeira nota: ");
        double nota1 = sc.nextDouble();
        System.out.println("Digite a segunda nota: ");
        double nota2 = sc.nextDouble();
        double resultado = (nota2+nota1)/2.0;
        if (resultado >=7){
            System.out.println("Aprovado na disciplina! :D");
        }else{
            System.out.println("Reprovado na disciplina!:(");
        }

        System.out.printf("Para a matéria "+disciplina2,":%n");
        System.out.println("Digite a primeira nota: ");
        nota1 = sc.nextDouble();
        System.out.println("Digite a segunda nota: ");
        nota2 = sc.nextDouble();
        resultado = (nota2+nota1)/2.0;
        if (resultado >=7){
            System.out.println("Aprovado na disciplina! :D");
        }else{
            System.out.println("Reprovado na disciplina!:(");
        }

    }
}
