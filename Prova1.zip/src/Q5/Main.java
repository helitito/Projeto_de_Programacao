package Q5;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
Aluno a = new Aluno();
a.cria();
a.aprova();
    }
}
