package condicional;
import condicional.comparador;
public class Program {

	public static void main(String[] args) {
		comparador a = new comparador();
		a.compara();
		// TODO Auto-generated method stub

	}

}
