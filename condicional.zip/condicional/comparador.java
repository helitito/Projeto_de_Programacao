package condicional;
import java.util.Scanner;
public class comparador {
	Scanner sc = new Scanner(System.in);
	int numero;
	
	public void compara() {
		System.out.println("Digite o numero: ");
		numero = sc.nextInt();
		if (numero>0) {
			System.out.println("Seu numero é Positivo!");
		}else if (numero<0) {
			System.out.println("Seu numero é Negativo!");
	}else {
		System.out.println("Você digitou 0 ele é Nulo!");
	}
 }
}