package duracao;
import java.util.Scanner;
public class duracaojogo {
	Scanner sc = new Scanner(System.in);
	int hora_inicial;
	int hora_final;
	int tempo;
	public void setHora_inicial(int hora_inicial) {
		hora_inicial = sc.nextInt();
	}
	
	
	public void setHora_final(int hora_fiinal) {
		hora_final = sc.nextInt();
	}

	public void calcula() {
		if (hora_final>hora_inicial) {
			int tempo = hora_final - hora_inicial;
			System.out.printf("O jogo durou "+tempo,"horas.");
		}else {
			int tempo = (hora_inicial+24)-hora_final;
		 }
		

    }
}