package intervalos;
import java.util.Scanner;
public class intervalo {
	Scanner sc = new Scanner(System.in);
	double numero;
	public void qual() {
		numero = sc.nextDouble();
		if (numero<=25) {
			System.out.println("Intervalo(0-25)");
		}else if (numero<=50) {
			System.out.println("Intervalo(26-50)");
		}else if (numero<=75) {
			System.out.println("Intervalo(51-75)");
		}
		else if (numero>=100){
			System.out.println("Intervalo(76-100)");
		}else {
			System.out.println("fora do intervalo)");
		}
	}

}
